global.informasibot = [`│`]
